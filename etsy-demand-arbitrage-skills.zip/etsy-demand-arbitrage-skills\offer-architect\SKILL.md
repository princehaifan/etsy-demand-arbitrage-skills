---
name: offer-architect
description: >
  Step 3 of 6 in the Etsy Demand Arbitrage Pipeline. Designs the product
  offer using the validated gap. Decides what goes in the box, sets the right
  price using the room-pricing model (not the aisle price), defines the
  format, and writes the listing copy that shows the buyer their own moment.
  Saves as offer_spec.md.
---

# Offer Architect

The $20 guy made $14,000 a month. The $197 version of his exact product exists.
The product did not change. The room changed.
20 is not what it is worth. 20 is what Etsy costs.
The ceiling is not set by what you built. It is set by where you are standing.
You are designing the offer before you pick the room.
Get the product right first. Price it for what it is worth, not what the aisle expects.
Save as `offer_spec.md`.

---

## Prerequisites

```
READ FIRST: signal_report.md → validated niche, top product breakdown, moat test
READ SECOND: gap_report.md   → product gap statement, what buyers are missing
```

---

## Step 1 — Define the Core Transformation

```
Before listing features, define the transformation.

THE BUYER'S BEFORE AND AFTER:
  Before: [what state is the buyer in when they search]
  After:  [what state do they want to be in after buying]

The product is the bridge between those two states.
Every feature you add must serve the transformation.
Features that do not move the buyer from Before to After are clutter.

VIDEO EXAMPLE (budget planner):
  Before: "My finances are a mess. I spend without tracking. I feel behind."
  After:  "I know exactly where every dollar goes. I feel in control."
  Bridge: A system with 28 tabs, automations, a tutorial, and a dashboard.
          Not a template. A system.

YOUR TRANSFORMATION STATEMENT:
  "A buyer who uses [product name] will go from [Before state]
   to [After state] in [timeframe]."

If you cannot write this sentence, you do not have a product yet.
```

---

## Step 2 — Design the Contents (What Goes In the Box)

```
BUILD RULE: Your product must pass the MOAT TEST.
  Could someone build this in 20 minutes in Canva?
  If YES → you are building in the saturated zone. Add more.
  If NO, it takes a week to learn → that week is protecting you.

CONTENT TIERS:

  TIER 1 — The Core File (required)
    The main deliverable: spreadsheet, template, tracker, system
    Must solve the gap identified in gap_report.md
    Must not break when the buyer types in the wrong box
    Must work on the platforms the buyer actually uses

  TIER 2 — The Tutorial (separates $20 from $197)
    A walkthrough video or step-by-step written guide
    Covers setup, common mistakes, how to customise
    Without this, buyers email you. With this, they leave 5 stars.
    VIDEO EXAMPLE: "YouTube tutorial included, no copy-paste required"
    This single addition is what made the $20 product worth $197 elsewhere.

  TIER 3 — The Maintenance Commitment (the real moat)
    "Updated version based on customer feedback"
    That note on the listing is a signal to buyers: this is maintained.
    Plan to ship at least one update in the first 3 months.
    One update + changelog = proof of commitment = higher perceived value.

  TIER 4 — Bonus Files (optional, only if they serve the transformation)
    Companion tracker, quick-start guide, cheat sheet, formula reference
    Only add bonuses that the buyer will actually open.
    Unused bonuses reduce perceived quality, not raise it.

RECORD EVERYTHING IN THE BOX:
  □ Core file(s): [list formats — Google Sheets, Excel, PDF, etc.]
  □ Tutorial: YES / NO — format: [video / PDF / written guide]
  □ Platforms supported: [list]
  □ Maintenance plan: [how often, what triggers an update]
  □ Bonuses: [list, or NONE]
```

---

## Step 3 — Price for the Room, Not the Aisle

```
THE AISLE PRICING TRAP:
  Etsy is an aisle. The buyer standing in that aisle expects to spend $12.
  The $1.98 guy priced for the aisle. So did the $20 guy.
  Both left money on the table.
  Etsy certified the $1.98 guy as excellent. Then paid him in aisle money.

THE ROOM PRICING MODEL:
  The same product in a different room commands a different price.
  VIDEO PROOF: The $20 Etsy budget system → $197 on a standalone checkout page.
               Same file. Same tabs. Same tutorial.
               Product did not change. Room changed.

PRICING EXERCISE:
  1. Write your intended price: $[X]
  2. Multiply by 10: $[10X]
  3. Ask: Does what is in the box justify [10X]?

  If NO:
    → That is not a pricing problem. That is a product value gap.
    → Add the tutorial. Add the maintenance. Add the transformation clarity.
    → Go back to Step 2 and build until the box justifies the number.

  If YES to 10X:
    → You are the $1.98 guy.
    → Your current price is a 4-second decision from 2 years ago.
    → Change it.

PRICE RANGES BY ROOM:

  ETSY ROOM (aisle pricing):
    Volume products: $5–$25
    Premium products: $25–$75

  OWN CHECKOUT PAGE (room pricing):
    Entry offer:   $27–$47
    Core product:  $67–$97
    Premium system: $147–$297

  RECOMMENDATION: Price for the room you are going TO, not the room you are IN.
  Even if you launch on Etsy first (for traffic and social proof),
  price it as if the goal is to move it to your own room eventually.
  $20 on Etsy beats $1.98 on Etsy. And $197 on your page beats both.
```

---

## Step 4 — Write the Listing That Shows the Moment

```
THE LISTING COPY PRINCIPLE:
  People do not buy the file. They buy the moment the file solves.

YOUR LISTING MUST SHOW THE BUYER THEIR OWN MOMENT.

  VIDEO EXAMPLE (funeral invitation):
    Not: "Digital funeral invitation template"
    YES: Image of a hand holding a phone, text invitation on screen
         Title: "Phone Invitation, Memorial Invites, Text Message Invite"
         The buyer sees: "That is me. I have 4 days. I need to text 100 people."

WRITE THE 30-SECOND MOMENT:
  Where is the buyer when they need this?
  What is on their screen?
  What are they about to do next?
  What does their life look like before they find your product?

  TEMPLATE:
    "You are [situation]. You have [timeframe]. You need to [task].
     But [current frustration]. [Product name] is built for exactly this moment."

LISTING TITLE (Etsy SEO):
  Include: the exact problem, the format, the audience, the outcome
  Avoid:  clever names the buyer would not type
  Test:   would a buyer in their 30-second moment search for this phrase?

LISTING IMAGE:
  Show the moment, not the file.
  Show the buyer doing the thing, not a screenshot of the spreadsheet.
  The image should trigger recognition: "That is me. I need that."

LISTING DESCRIPTION STRUCTURE:
  1. The moment (1 paragraph — make them feel seen)
  2. What it includes (bullet list — specific, no fluff)
  3. How it works (numbered steps — simple)
  4. Who it is for (1–2 sentences — name the buyer)
  5. What they get (formats, file types, access)
  6. The update promise ("Updated based on customer feedback")
```

---

## Output File: offer_spec.md

```markdown
# Offer Specification
Pipeline step: 3 of 6
Date: [date]
Niche: [from signal_report.md]

---

## Transformation Statement
Before : [buyer's before state]
After  : [buyer's after state]
Bridge : [what the product does to get them there]

## The Box — What Is Included
Core file(s)      : [list]
Formats           : [Google Sheets / Excel / PDF / etc.]
Platforms         : [list]
Tutorial          : YES / NO — [format and length]
Maintenance plan  : [update trigger and frequency]
Bonuses           : [list or NONE]
Moat test result  : PROTECTED / EXPOSED [explain]

## Pricing
Aisle price (Etsy) : $[X]
Room price (own page): $[X]
Current intention  : $[X] on [platform]
10× stress test    : [does the box justify it? YES/NO + reasoning]

## The 30-Second Moment
[2–3 sentences describing the exact moment the buyer is in]

## Listing Copy Draft

TITLE: [listing title with keywords]

HOOK (first line of description):
[The moment paragraph]

INCLUDES:
  • [item]
  • [item]
  • [item]

HOW IT WORKS:
  1. [step]
  2. [step]
  3. [step]

LISTING IMAGE CONCEPT:
[Describe what the image should show — the moment, not the file]

---

## Pipeline Status
Step 1 ✅ signal-hunter  → signal_report.md
Step 2 ✅ gap-finder     → gap_report.md
Step 3 ✅ offer-architect→ offer_spec.md
Step 4 ⬜ room-builder   → room_plan.md
Step 5 ⬜ product-launcher→ launch_checklist.md
Step 6 ⬜ empire-scaler  → scale_plan.md
```

---

## Review Gate (MANDATORY)

After saving `offer_spec.md`, present this EXACTLY:

```
✅ Offer specification complete. Saved to offer_spec.md.

📋 Summary:
- Transformation    : [Before → After]
- What is in the box: [brief list]
- Moat test         : PROTECTED / EXPOSED
- Aisle price       : $[X]
- Room price        : $[X]
- Listing hook      : [first line of description]
- 30-second moment  : [one sentence]

👉 You can:
  - Approve → say "approved" or "build the room"
  - Adjust the offer → say "add [feature] to the box"
  - Change the price → say "price it at $[X]"
  - Rewrite the hook → say "rewrite the listing hook"

⏸️ Waiting for approval before Room Builder runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `build the room`, `room builder`,
`proceed`, `next`, `go`, `offer approved`, `design the room`
