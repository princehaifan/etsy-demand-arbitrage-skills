---
name: product-launcher
description: >
  Step 5 of 6 in the Etsy Demand Arbitrage Pipeline. Builds, tests, and
  ships the product. Covers file quality checklist, tutorial recording,
  Etsy listing setup, own-page checkout setup, first-sale checklist, and
  the feedback collection system that drives the first update.
  Saves as launch_checklist.md.
---

# Product Launcher

The $20 guy built the formulas. He made it not break.
He recorded the tutorial. He went back and fixed it when customers complained.
He did the part where it stops being fun.
That is the whole moat.
14 grand a month, 412,000 a year, because he was willing to be bored.
Now you build it. Ship it. Collect the feedback.
The first version does not have to be perfect. It has to ship.
Save as `launch_checklist.md`.

---

## Prerequisites

```
READ FIRST: offer_spec.md  → what goes in the box, formats, transformation
READ SECOND: room_plan.md  → platform, pricing, bridge, email sequence
```

---

## Step 1 — Build the Core Product File

```
QUALITY RULES (the things that kill reviews if skipped):

  □ It does not break when the buyer types in the wrong cell
     → Protect formula cells. Lock them. Test by entering bad data.
     → If a buyer enters text in a number field, what happens?
        It should warn them or ignore the input, never crash.

  □ It works on the platform the buyer actually uses
     → Google Sheets: test on a free Google account, not your own
     → Excel: test on Excel 365 AND Excel 2019 (older versions break)
     → If you support both: test both. Every time.

  □ It is shared correctly
     → Google Sheets: "Make a copy" link, NOT edit access to your file
       Link format: change /edit at end of URL to /copy
     → This is the most common beginner mistake. Test it.

  □ It looks like a finished product, not a personal file
     → Clean the tab names (no "Sheet1", "Copy of Sheet2")
     → Remove all test data. Start fresh from the buyer's perspective.
     → Consistent fonts, consistent colours, consistent formatting

  □ Instructions are inside the file
     → Tab 1 (or first visible cell): "Start here" or "Setup guide"
     → This is what the buyer opens first. Make it foolproof.

  □ The bridge is in the file
     → Your email capture / bonus opt-in link is on the first tab
     → Visible immediately when the file opens
```

---

## Step 2 — Record the Tutorial

```
THE TUTORIAL IS NOT OPTIONAL.

VIDEO PROOF:
  The $20 budget planner listing says:
  "YouTube tutorial included, no copy-paste required"
  That one line is the difference between $20 and $197 perceived value.
  Buyers who watch the tutorial before buying convert at higher rates.
  Buyers who watch it after buying leave better reviews.

TUTORIAL FORMAT OPTIONS:
  1. YouTube (unlisted video) → link in product file and listing
  2. Loom (free tier) → quick, easy, no editing required
  3. PDF walkthrough → slower to consume, but searchable
  4. All three → overkill for v1, but great for a premium tier

WHAT TO COVER IN THE TUTORIAL:
  1. Quick intro (30 seconds): what this is, who it is for, what they will get
  2. Where to start: the exact tab or cell to open first
  3. How to set it up: step-by-step, screen share, narrated
  4. The most common mistake: address it before they make it
  5. How to get help: reply to your email, your contact link

TUTORIAL QUALITY RULES:
  □ Audio must be clear (use a decent mic, or record from a quiet room)
  □ Screen must be readable (record at 1080p or higher)
  □ Narrate what you are doing, not just what is on screen
  □ Under 20 minutes. Buyers will not watch longer.
  □ No intro music. Start talking immediately.

TUTORIAL TITLE (for YouTube):
  "[Product name] Tutorial — Full Setup Walkthrough [year]"
  Add the year. Signals that it is maintained and current.
```

---

## Step 3 — Set Up the Etsy Listing (if using Etsy first)

```
LISTING SETUP CHECKLIST:

  □ Title
     Use the listing title from offer_spec.md
     Max 140 characters. Put the most searchable phrase first.
     Include: file format + main benefit + niche keyword

  □ Category
     Digital downloads → Spreadsheets / Templates / Planners
     Do not overthink this. Match what the top sellers use.

  □ Price
     Use the room price from offer_spec.md. NOT aisle price.
     This is the decision. 4 seconds. Do not type $1.98.

  □ Description
     Use the full listing description from offer_spec.md
     Start with the moment paragraph. Never start with "Welcome to my shop."

  □ Tags (13 max)
     Include: niche keyword, file format, buyer problem, platform,
              outcome word (organise, track, automate, manage)

  □ Images
     Image 1: the moment (buyer in the situation, not a screenshot)
     Image 2: the product preview (screenshot of the actual file)
     Image 3: what is included (clean bullet list graphic)
     Image 4–5 (optional): specific features, before/after

  □ Files to upload
     Google Sheets: upload a PDF with the "Make a copy" link
     Excel: upload the .xlsx file directly
     Tutorial link: include in the PDF and in the description

  □ Processing time
     Digital: set to instant delivery
     Do not say "1–2 business days" for a digital product. It kills conversions.
```

---

## Step 4 — Set Up the Own Checkout Page

```
MINIMUM VIABLE CHECKOUT PAGE:

  Platform: [from room_plan.md]

  PAGE ELEMENTS IN ORDER:
    1. Headline (from offer_spec.md)
    2. What is included (bullet list from offer_spec.md)
    3. Price + Buy button
    4. Social proof (add once you have 3+ reviews)
    5. Guarantee (if you are offering one)

  AFTER PURCHASE FLOW:
    → Buyer pays
    → Redirect to thank-you page (build this)
    → Thank-you page: download link + "claim your bonus" opt-in
    → Email delivery: automated from your email platform

  THANK-YOU PAGE CONTENT:
    Headline: "You're in. Here is what to do next."
    1. Download link (button)
    2. Tutorial link (button or embed)
    3. "Get your free bonus: [bonus name]" → email opt-in form
    4. "While you are here, follow me on [platform]" (optional)
```

---

## Step 5 — The Feedback Collection System

```
THE $20 GUY TOOK A YEAR.
You are going to collect the same data in 30 days.

AFTER FIRST SALE — do these:

  □ REPLY TO EVERY REVIEW in the first 30 days
     Even 5-star reviews. It signals to Etsy and future buyers
     that you are present and responsive.
     Reply to 3-star reviews FAST. Within 24 hours if possible.

  □ EMAIL 3 TRIGGERS RESEARCH (from room_plan.md):
     "What would you want from a [related product]?"
     Every reply is a validated feature request or second product idea.
     Log them. This is the update that ships next month.

  □ TRACK YOUR OWN QUESTIONS:
     Every time a buyer emails or messages you with a question,
     add it to a list. 3 people asked the same question =
     something is confusing. Fix it in the tutorial or the file.

  □ CHANGELOG (start it now, before you need it):
     Create a tab in your product file called "Updates"
     Log every change with a date.
     "Updated version based on customer feedback" is the note
     that tells buyers: this is maintained. This is worth $20.

THE UPDATE CYCLE (aim for one update in first 90 days):
  Trigger: 3 or more buyers ask about the same missing feature
           or complain about the same thing
  Action:  Add the feature. Update the changelog. Update the listing.
           Email your list: "New version just dropped — re-download here"
  Result:  Existing buyers re-engage. New buyers see the changelog.
           Trust goes up. Conversion rate goes up.
```

---

## Output File: launch_checklist.md

```markdown
# Launch Checklist
Pipeline step: 5 of 6
Date: [date]
Product: [product name from offer_spec.md]

---

## Product File Quality
[ ] Formula cells protected
[ ] Bad input testing passed (typed wrong data — did not crash)
[ ] Google Sheets "Make a copy" link tested on a fresh account
[ ] Excel version tested on [versions]
[ ] Tab names cleaned
[ ] Test data removed
[ ] "Start here" instructions on tab 1
[ ] Email bridge link visible on first open

## Tutorial
[ ] Tutorial recorded — format: [YouTube / Loom / PDF]
[ ] Audio quality checked
[ ] Under 20 minutes
[ ] Covers: intro, setup, common mistakes, how to get help
[ ] Link placed in product file on tab 1
[ ] Link placed in listing description

## Etsy Listing (if applicable)
[ ] Title set (uses listing title from offer_spec.md)
[ ] Price set: $[X]
[ ] Description set (from offer_spec.md)
[ ] Tags: [list]
[ ] Images uploaded: [N] images
[ ] Files uploaded correctly
[ ] Instant delivery confirmed
Listing URL: [to be filled after publish]

## Own Checkout Page
[ ] Page live on [platform]
[ ] Headline matches offer_spec.md
[ ] Buy button working
[ ] Payment tested with test card
[ ] Thank-you page built
[ ] Download delivery working
[ ] Email opt-in on thank-you page connected to [email platform]
[ ] Welcome sequence active (emails 1–3 from room_plan.md)
Page URL: [to be filled after publish]

## First 30 Days Feedback System
[ ] Review reply plan: within 48 hours for all, 24 hours for 3-star
[ ] Email 3 (second product research) scheduled for Day 7
[ ] Buyer questions log: started
[ ] Changelog tab: created in file
[ ] Update trigger: 3+ identical complaints = ship an update

## First Sale Target
Goal: [N] sales in first 30 days
Revenue target: $[X]
Platform split: Etsy [N] / Own page [N]

---

## Pipeline Status
Step 1 ✅ signal-hunter  → signal_report.md
Step 2 ✅ gap-finder     → gap_report.md
Step 3 ✅ offer-architect→ offer_spec.md
Step 4 ✅ room-builder   → room_plan.md
Step 5 ✅ product-launcher→ launch_checklist.md
Step 6 ⬜ empire-scaler  → scale_plan.md
```

---

## Review Gate (MANDATORY)

After saving `launch_checklist.md`, present this EXACTLY:

```
✅ Launch checklist complete. Saved to launch_checklist.md.

📋 Summary:
- Product file        : [READY / PENDING — what is missing]
- Tutorial            : [RECORDED / PENDING]
- Etsy listing        : [LIVE / PENDING — URL if live]
- Own checkout page   : [LIVE / PENDING — URL if live]
- Email sequence      : [ACTIVE / PENDING]
- Feedback system     : [SET UP / PENDING]
- First sale target   : [N] sales / $[X] in 30 days

Outstanding before launch:
  [list anything not checked]

👉 You can:
  - Approve → say "approved" or "build the empire"
  - Fix an item → say "fix [item from checklist]"
  - Set a launch date → say "launch on [date]"

⏸️ Waiting for approval before Empire Scaler runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `build the empire`, `empire scaler`,
`proceed`, `next`, `go`, `launch approved`, `scale it`
