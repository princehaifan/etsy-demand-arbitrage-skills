---
name: gap-finder
description: >
  Step 2 of 6 in the Etsy Demand Arbitrage Pipeline. Mines four free public
  sources — Etsy reviews, Reddit, Google Autocomplete, and AI-assisted review
  analysis — to find the product gap that existing top sellers have not filled.
  Turns complaints into a product brief. Saves findings as gap_report.md.
---

# Gap Finder

The $20 guy found his product gap the expensive way.
One year. Customer complaints. Refund requests. One-star reviews at 11pm.
"Updated version based on customer feedback."
That data was public before he built anything.
You do not have to bleed for a year to gather it.
Four free sources. One afternoon. The same gap, without the year.
Save your findings as `gap_report.md`.

---

## Prerequisites

```
READ FIRST: signal_report.md → confirmed niche, top listings, GO decision
```

---

## Source 1 — Etsy Reviews (What Is Broken)

```
TARGET: Top 3 listings in your confirmed niche
SOURCE: Their Etsy review pages — public, free

READ: NOT the 5-star reviews. Read the 3-star reviews.

WHY 3 STARS:
  5 stars → happy, no information
  1 star  → angry, often extreme, sometimes unfair
  3 stars → "I wanted this to work. It almost did."
             That is the most valuable writing on the internet for you.
             These are people who bought, tried, cared enough to stay,
             and then wrote down exactly what was missing.

HOW TO READ THEM:
  1. Open each of the top 3 listings
  2. Filter reviews: 3 stars
  3. Copy every 3-star review into a document
  4. Also copy any 4-star reviews that mention a complaint
  5. Aim for 30–50 reviews total

WHAT TO LOOK FOR:
  □ Recurring feature requests ("I wish it had…")
  □ Compatibility complaints ("doesn't work on mobile / Mac / older Excel")
  □ Complexity complaints ("too hard to set up", "broke when I added data")
  □ Missing functionality ("no [X] tab", "can't track [Y]")
  □ Support complaints (unanswered questions, no tutorial, no updates)

THIS IS COMPETITOR CUSTOMER RESEARCH ON A LISTING THAT ALREADY EXISTS.
You are reading his feedback before you build anything.
He took a year to gather this. You are reading it in an afternoon.
```

---

## Source 2 — AI Review Analysis

```
DO NOT USE AI TO GENERATE PRODUCT IDEAS.
DO USE AI TO READ 40 PAGES OF CUSTOMER RESEARCH IN 9 SECONDS.

WRONG WAY:
  "Claude, write me a niche digital product idea."
  → You get the average of everything that already exists.
  → Average is the saturation.

RIGHT WAY:
  Paste your 30–50 reviews into Claude and prompt:

  PROMPT TO USE:
  ---
  Here are [N] reviews of a top-selling [product type] on Etsy.
  Find every recurring complaint.
  Group them by theme.
  Tell me which complaint shows up most across all reviews.
  Then tell me what a product would need to do specifically to fix
  the most common complaint.
  Do not suggest a product name. Just describe the missing capability.
  ---

  What comes back is not AI writing your product.
  It is AI reading a year of customer feedback in 9 seconds
  and handing you the gap.
  Research assistant. Not a factory.

RECORD:
  □ Top complaint theme (most frequent)
  □ Second complaint theme
  □ Third complaint theme
  □ The specific capability that would fix the top complaint
```

---

## Source 3 — Reddit (What People Could Not Find)

```
Etsy tells you what people bought.
Reddit tells you what they wanted and could not find.
That gap is where your product lives.

SUBREDDITS TO SEARCH (match to your niche):
  Spreadsheets / budgeting  → r/personalfinance, r/financialindependence,
                               r/YNAB, r/excel, r/googlesheets
  Wedding                   → r/weddingplanning, r/weddingplanning
  Fitness / health          → r/fitness, r/loseit
  Small business            → r/smallbusiness, r/entrepreneur
  Teachers / education      → r/teachers, r/teachingresources

SEARCH PHRASES (replace [niche] with your category):
  "[niche] I wish there was"
  "[niche] does anyone know how to"
  "[niche] why is there no"
  "[niche] can't find a"
  "[niche] recommendation for"
  "[niche] frustrated with"

WHAT YOU ARE LOOKING FOR:
  Someone describes a specific problem AND gets no good answer.
  That is not a complaint. That is an order form.

RECORD:
  □ Post title + subreddit + date
  □ The exact problem described
  □ Why existing answers/products did not solve it
  □ Upvote count (high upvotes = many people had the same problem)
```

---

## Source 4 — Google Autocomplete (What People Are Asking)

```
RULE: The questions people type into Google are the products people buy.

HOW TO USE IT:
  Open Google. Type your niche. Do NOT press enter.
  Watch what autocomplete suggests.
  Those are real searches from real people, right now.

Then run these question formats:
  "how do I [niche] that [qualifier]"
  "best [niche] for [specific audience]"
  "why does my [niche] not [outcome]"
  "[niche] template that [specific feature]"

VIDEO EXAMPLE:
  Search: "monthly budget"
  Autocomplete: "monthly budget that I'll actually stick to"
  → That is a search.
  → It is also a spreadsheet, a walkthrough, and a $97 system.
  The question already tells you what the product needs to do.

RECORD:
  □ Top 5–10 autocomplete suggestions in your niche
  □ For each: what product would directly answer this question?
  □ Circle the ones that match what the reviews and Reddit also showed
```

---

## Step 5 — Triangulate the Gap

```
THE FOUR-SOURCE CONVERGENCE TEST:

A signal that appears in one source is a hint.
A signal that appears in all four sources is a validated product.

SOURCE ALIGNMENT CHECK:
  Etsy reviews mention        : [recurring complaint]
  Reddit is asking for        : [same unmet need]
  Google autocomplete shows   : [same search intent]
  AI review analysis found    : [same gap theme]

If the same problem appears in all four → that is not an idea.
That is a validated product. Build it.

If it only appears in one or two → keep searching or note it
as a secondary opportunity.

THE PRODUCT GAP STATEMENT (write this in one sentence):
  "Buyers in [niche] consistently want [specific feature or outcome]
   but no existing top product delivers it because [reason].
   A product that [does X] would solve this."

This sentence is worth more than any product name.
It is the brief. Everything in the next step flows from it.
```

---

## Output File: gap_report.md

```markdown
# Gap Report
Pipeline step: 2 of 6
Date: [date]
Niche: [from signal_report.md]

---

## Review Analysis
Listings reviewed  : [N]
Total reviews read : [N]
3-star reviews     : [N]

Top complaint themes (ranked by frequency):
1. [theme] — [X occurrences] — "[example quote]"
2. [theme] — [X occurrences] — "[example quote]"
3. [theme] — [X occurrences] — "[example quote]"

The specific missing capability:
[what a product would need to do to fix complaint #1]

## Reddit Findings
Subreddits searched: [list]
Unmet need posts found: [N]

Top post: [title] | r/[sub] | [upvotes] upvotes
Problem: [describe]
Why existing answers failed: [describe]

## Google Autocomplete
Top searches in niche:
1. [autocomplete phrase]
2. [autocomplete phrase]
3. [autocomplete phrase]
Strongest signal: [which phrase, why]

## Four-Source Convergence
| Source      | Signal Found | Matches Gap Theme |
|-------------|--------------|-------------------|
| Etsy reviews| YES / NO     | [describe]        |
| Reddit      | YES / NO     | [describe]        |
| Google      | YES / NO     | [describe]        |
| AI analysis | YES / NO     | [describe]        |

Convergence score: [X / 4 sources]

## The Product Gap Statement
"[One sentence: buyers want X, nothing delivers it, here is what would fix it]"

## Secondary Opportunities
[Any gaps that showed up in 2 sources but not all 4]

---

## Pipeline Status
Step 1 ✅ signal-hunter  → signal_report.md
Step 2 ✅ gap-finder     → gap_report.md
Step 3 ⬜ offer-architect→ offer_spec.md
Step 4 ⬜ room-builder   → room_plan.md
Step 5 ⬜ product-launcher→ launch_checklist.md
Step 6 ⬜ empire-scaler  → scale_plan.md
```

---

## Review Gate (MANDATORY)

After saving `gap_report.md`, present this EXACTLY:

```
✅ Gap research complete. Saved to gap_report.md.

📋 Summary:
- Reviews analysed      : [N]
- Top complaint theme   : [theme]
- Reddit posts found    : [N]
- Google signals        : [top phrase]
- Convergence score     : [X/4]
- Product gap statement : [one sentence]

👉 You can:
  - Approve → say "approved" or "build the offer"
  - Add a source → say "also check [subreddit/keyword]"
  - Refine the gap → say "gap should focus on [X]"

⏸️ Waiting for approval before Offer Architect runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `build the offer`, `offer architect`,
`proceed`, `next`, `go`, `gap approved`, `design the offer`
