---
name: signal-hunter
description: >
  Step 1 of 6 in the Etsy Demand Arbitrage Pipeline. Finds validated,
  high-volume digital product demand using public Etsy data and Profit Tree
  (free tier). Searches by category, not product. Identifies the top performer
  in a niche, reads volume signals, and rules niches in or out in one session.
  Saves findings as signal_report.md.
---

# Signal Hunter

Etsy is not the opportunity. Etsy is the receipts.
It is the largest public record of what ordinary people are already pulling out a credit card for.
Every number on the screen is a market test somebody already ran and already paid for.
You are not here to open a shop. You are here to read the demand before you build anything.
Search the category. Not the product. Find the signal. Save it as `signal_report.md`.

---

## Prerequisites

```
TOOL REQUIRED: Profit Tree (profittree.io) — free tier is sufficient
  Free tier gives one row per search and blurs most data.
  That is enough. You need the top performer, not the whole list.

ETSY DIRECT: etsy.com is free. The "X sold in the past 24 hours" badge
  is on the listing — Etsy put it there. Free. Same signal as the tool.

START WITH: A category or niche keyword (e.g. "spreadsheets", "wedding invitations",
  "funeral products") — NOT a specific product title.
```

---

## Step 1 — Set Up the Category Search

```
PRINCIPLE: Search the category, not the product.

WHY IT MATTERS:
  "Floral pink outdoor wedding invitation" → shows you ONE product
  "Wedding invitation"                    → shows you the top performer
                                            across the whole space

A category search tells you TWO things at once:
  1. What is working right now
  2. Whether the niche is worth your time at all

RULE: If the top product in a category makes under $500/month,
  that is not competition — that is nobody wanting it. Move on.
  That one filter alone saves you 3 months.

HOW TO SEARCH:
  Option A: Profit Tree → click "Hot on Etsy" filter → type category keyword
  Option B: Etsy.com → search category → sort by Most Recent or Bestseller
            → look for listings showing "X sold in the past 24 hours"
```

---

## Step 2 — Read the Top Performer

```
WHAT TO RECORD for the top listing in the category:

  □ Product title
  □ Price
  □ Estimated monthly sales (from Profit Tree, or count recent reviews × 3)
  □ Estimated monthly revenue (price × monthly sales)
  □ Total reviews (proxy for total lifetime sales)
  □ Star rating
  □ Star Seller badge: YES / NO
  □ Shop age (years on Etsy)
  □ "In carts right now" count (if visible)
  □ "Views today" count (if visible)
  □ "Sold in last 24 hours" badge text

WHAT THE LISTING IMAGE SHOWS:
  □ What problem does the image show, not the product?
  □ What is the buyer doing in the image?
  □ What moment are they already living when they need this?

  EXAMPLE FROM THE VIDEO:
    Funeral invitation listing → showed a hand holding a phone
    Not because it was a phone wallpaper — because the buyer
    is not printing anything. They have 4 days and 100 people
    to reach. They are texting it.
    The image showed the exact moment the buyer already has in their head.
    People do not buy the file. They buy the moment the file solves.
```

---

## Step 3 — Niche Volume Check

```
CATEGORY-LEVEL SIGNAL (from Profit Tree category total, or manual estimate):

  Under $1,000/month    → nobody wants this. Skip.
  $1,000–$10,000/month  → small niche. Possible if top listing is $20+.
  $10,000–$100,000/month → real market. Worthy of research.
  $100,000+/month       → this is a company's revenue spread across sellers.
                          High competition, but the demand is undeniable.

  VIDEO EXAMPLE: "Spreadsheet" as a single category word
    → $640,000/month
    That is not a niche. That is a company revenue.

NICHE SCORE (Profit Tree):
  100 = maximum demand signal for this category right now
  Anything 80+ is worth going deeper.
```

---

## Step 4 — The Price vs. Volume Stress Test

```
FIND TWO LISTINGS IN THE SAME CATEGORY:
  One at a low price point ($1–$5)
  One at a higher price point ($15–$30)

RECORD BOTH:
  | Metric              | Low Price | High Price |
  |---------------------|-----------|------------|
  | Price               |           |            |
  | Monthly sales       |           |            |
  | Monthly revenue     |           |            |
  | Star rating         |           |            |
  | Star Seller badge   |           |            |
  | Shop age            |           |            |
  | Lifetime revenue    |           |            |

CALCULATE: Annual revenue for each at current pace.

VIDEO EXAMPLE:
  $1.98 guy: 2 years, 4.8★, Star Seller, 2,500 sales/month → $4,950/month
  $20 guy:   1 year,  4.8★, no badge,   708 sales/month   → $14,000/month
  Annual:    $1.98 guy → ~$59,400 | $20 guy → ~$168,000
  Multiply:  $20 guy made 4× the money in HALF the time.
  Same rating. Same category. Same file type.
  Price is the lever.

EXERCISE (do this now, before moving on):
  Look at whatever you plan to sell.
  Write down your intended price.
  Multiply by 10.
  Ask: Does what is in the box justify that number?
  If NO → that is not a pricing problem. That is a product value gap.
           You just found what to build next.
  If YES → you are the $1.98 guy. You are leaving money on the table
           because you never asked.
```

---

## Step 5 — Read What the Top Product Actually Ships

```
For the highest-revenue listing in your category, record EXACTLY:
  □ What is in the product? (tabs, automations, formats, bonuses)
  □ Is there a tutorial video?
  □ Is there a changelog / "updated based on feedback" note?
  □ What file types are included?
  □ What platforms does it support?

VIDEO EXAMPLE ($20 budget planner):
  28 tabs
  Recurring automations
  Excel AND Google Sheets
  YouTube tutorial included
  No copy-paste required
  Automated dashboard
  Global currency support
  Updated version based on customer feedback (changelog)

  That is not a template. That is a system with automations,
  a walk-through video, and a maintenance log.
  He did not make a template. He shipped a product, and then maintained it.
  He did the part where it stops being fun. That is the whole moat.

THE MOAT QUESTION:
  Could someone build this in 20 minutes in Canva?
  YES → knife fight. Thousands of them. No barrier.
  NO, takes a week to learn → that week is the only thing standing
     between you and everyone else.
  Pick the week. The barrier is not in your way. The barrier is protecting you.
```

---

## Output File: signal_report.md

```markdown
# Signal Report
Pipeline step: 1 of 6
Date: [date]
Category searched: [category keyword]

---

## Category Overview
Monthly category volume   : $[X]
Niche score               : [X/100]
Worth pursuing            : YES / NO / MAYBE

## Top Performer
Product title   : [title]
Price           : $[X]
Monthly sales   : ~[X]
Monthly revenue : ~$[X]
Lifetime revenue: ~$[X]
Rating          : [X]★
Star Seller     : YES / NO
Shop age        : [X] years
Listing image   : [describe what problem/moment the image shows]

## Price vs. Volume Comparison
| Metric           | Low-Price Listing | High-Price Listing |
|------------------|-------------------|--------------------|
| Price            |                   |                    |
| Monthly sales    |                   |                    |
| Monthly revenue  |                   |                    |
| Annual revenue   |                   |                    |
| Star rating      |                   |                    |
| Shop age         |                   |                    |
Revenue multiple  : [X]×

## What the Top Product Ships
[bullet list of everything included]

## The Moat Test
Could this be built in Canva in 20 min? YES / NO
Barrier to entry: [describe]

## The 30-Second Buyer Moment
[Write the exact 30 seconds your buyer is in when they need this product.
 Where are they? What's on their screen? What are they about to do next?]

## Go / No-Go
Decision        : GO / NO-GO
Reason          : [one sentence]

---

## Pipeline Status
Step 1 ✅ signal-hunter  → signal_report.md
Step 2 ⬜ gap-finder     → gap_report.md
Step 3 ⬜ offer-architect→ offer_spec.md
Step 4 ⬜ room-builder   → room_plan.md
Step 5 ⬜ product-launcher→ launch_checklist.md
Step 6 ⬜ empire-scaler  → scale_plan.md
```

---

## Review Gate (MANDATORY)

After saving `signal_report.md`, present this EXACTLY:

```
✅ Signal report complete. Saved to signal_report.md.

📋 Summary:
- Category            : [name]
- Monthly volume      : $[X]
- Top listing revenue : $[X]/month
- Price lever verdict : [what the comparison showed]
- Moat test           : [PROTECTED / EXPOSED]
- Buyer's 30 seconds  : [one sentence]
- Decision            : GO / NO-GO

👉 You can:
  - Approve → say "approved" or "find the gap"
  - Change category → say "try [new category]"
  - Add a listing → say "also check [listing title]"

⏸️ Waiting for approval before Gap Finder runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `find the gap`, `gap finder`,
`proceed`, `next`, `go`, `signal approved`, `research the gap`
