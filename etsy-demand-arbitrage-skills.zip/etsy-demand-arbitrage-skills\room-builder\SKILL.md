---
name: room-builder
description: >
  Step 4 of 6 in the Etsy Demand Arbitrage Pipeline. Builds the "room" —
  the checkout page, email list, and owned customer relationship that lets
  the seller escape the Etsy aisle. Maps the checkout page, the thank-you
  sequence, and the second-product upsell path. Saves as room_plan.md.
---

# Room Builder

The $20 guy does not own the customer.
708 people a month hand him money and tell him: "I am trying to get my finances under control."
That is the most qualified customer in personal finance.
And he will never speak to them again.
Etsy has the email. Etsy has the relationship.
He got a payout and a review.
That listing is one algorithm change from a very bad Tuesday.
He did not build the road. He rents a stall on it.
You are going to build the road. Save as `room_plan.md`.

---

## Prerequisites

```
READ FIRST: signal_report.md → validated niche, top product data
READ SECOND: offer_spec.md   → product, price, transformation statement
```

---

## The Room vs. The Aisle — The Core Distinction

```
THE AISLE (Etsy):
  - Buyer searches a phrase
  - Finds your listing among hundreds
  - Buys for aisle price ($2–$20)
  - Etsy takes the email
  - Etsy takes the relationship
  - Etsy takes the future purchases
  - You got a payout

THE ROOM (your own checkout page):
  - Buyer finds you (from Etsy traffic, social, search, word of mouth)
  - Lands on a page you own
  - Pays a room price ($67–$197)
  - You take the email
  - You take the relationship
  - You build the future purchases
  - That is a business

THE REFRAME FROM THE VIDEO:
  Etsy is not the opportunity. Etsy is the receipts.
  It is the proof that demand exists. Use the proof. Build the room.

TWO VALID STRATEGIES:
  1. ETSY FIRST → Etsy listing for traffic + social proof → drive to own page
  2. OWN PAGE ONLY → use the Etsy signal to price and build, skip the aisle

For most people starting out: Strategy 1.
Etsy gives you volume data. Use it. But treat it as the funnel top, not the destination.
```

---

## Step 1 — The Checkout Page

```
PLATFORM OPTIONS (pick one):
  Gumroad     → simplest, lowest friction, 10% fee on free plan, 5% on paid
  Lemon Squeezy → developer-friendly, good for SaaS-style products
  Payhip      → free tier, digital + physical, no monthly fee
  Shopify     → overkill for one product but scales
  Stan Store  → creator-friendly, link-in-bio integrated
  Podia       → includes email, courses, community

CHECKOUT PAGE STRUCTURE (every page needs all of these):

  1. HEADLINE (the transformation, not the product name)
     NOT: "Budget Planner Spreadsheet"
     YES: "Finally know exactly where every dollar goes — in 10 minutes"

  2. SUBHEADLINE (the moment + the credibility)
     "Built for people who have tried other budgets and given up.
      28 tabs. Automated. Includes a full setup tutorial."

  3. WHAT IS INCLUDED (specific, scannable)
     • 28-tab Google Sheets system
     • Excel version included
     • 20-minute video walkthrough
     • Automated income/expense dashboard
     • Global currency support
     • Free updates for life

  4. WHO IS IT FOR (name the buyer out loud)
     "This is for you if: you are tired of guessing your finances,
      you have tried other budget sheets and they broke,
      you want something that works without an accounting degree."

  5. SOCIAL PROOF (reviews from Etsy or early buyers)
     Real quotes. Real names (first name only is fine). Real results.

  6. THE PRICE + THE BUY BUTTON
     Price: $[room price from offer_spec.md]
     Button: "Get instant access" or "Download now"
     Below the button: "Instant digital delivery. No subscription."

  7. THE GUARANTEE (optional but powerful)
     "If it does not work for you, email me within 30 days. Full refund."
     This eliminates risk for the buyer. It increases conversion significantly.
     For a $20–$97 digital product: virtually nobody claims it.
```

---

## Step 2 — The Email Capture and Sequence

```
THE RULE: The email is worth more than the sale.
  708 Etsy buyers × $0 email value = $0 future revenue
  708 email subscribers × $20 second product = $14,160 from one email

HOW TO CAPTURE:
  OPTION A (Etsy → email list):
    Include a "bonus download" in the product delivery file
    Link to a simple opt-in page: "Get the [bonus] → enter your email"
    Bonus examples: companion tracker, quick-start PDF, formula cheat sheet
    When they opt in → they are on your list, not Etsy's

  OPTION B (own checkout page):
    Email is captured at checkout automatically
    Every buyer is on your list from day one

EMAIL PLATFORM OPTIONS:
  Kit (formerly ConvertKit)  → best for digital product sellers
  Beehiiv                    → great for newsletter-based businesses
  Mailchimp (free tier)      → 500 contacts free, basic automations
  MailerLite                 → generous free tier, good templates

THE WELCOME SEQUENCE (3 emails minimum):

  EMAIL 1 — Day 0 (delivery):
    Subject: "Your [product name] is here — start here first"
    Body: Download link + the one thing they should set up first
          + invite to reply if they have any questions

  EMAIL 2 — Day 3 (the win):
    Subject: "Did you try [the main feature] yet?"
    Body: Short tip for getting the most out of the product
          + a real use case or example
          + soft ask: "Reply and tell me how it's going"

  EMAIL 3 — Day 7 (the relationship):
    Subject: "One thing I see people miss with [product name]"
    Body: The most common mistake + how to avoid it
          + mention that you are building something new
          + ask: "What would you want from a [related product]?"
          → This email does two things: builds trust AND
            validates your second product idea for free.
```

---

## Step 3 — The Etsy-to-Room Bridge

```
IF YOU ARE LAUNCHING ON ETSY FIRST:

Your Etsy listing is the top of the funnel.
Your checkout page is the room.
You need a bridge between them.

THE BRIDGE OPTIONS:

  OPTION A — Bonus in the product file:
    Inside the product file (first tab, top cell):
    "Want the [Companion Tracker] for free?
     Download at [your landing page URL]"
    When they go to claim the bonus → they are in your room.

  OPTION B — Tutorial on YouTube:
    Your tutorial video is on your YouTube channel.
    At the end of the tutorial: "Get the premium version
    with [extra feature] at [your page]"
    Etsy buyers become YouTube viewers become email subscribers.

  OPTION C — Thank-you page redirect:
    After Etsy checkout, Etsy does not let you redirect.
    But your product file CAN contain a link to a thank-you page
    you built. That page captures the email.

WHAT NOT TO DO:
  Do not include an Etsy shop link.
  Do not send people back to Etsy.
  Every click you send back to Etsy is a click you gave away.
```

---

## Step 4 — The Second Product Path

```
VIDEO PROOF OF THE MULTIPLIER:
  708 buyers per month. Each one said "I need to get my finances under control."
  Next month he sends those buyers: the debt payoff tracker.
  A chunk of them buy. Because he is the person who already helped them once.

This is the entire business model in one paragraph.
One person with one problem buys one product.
You solve it. You earn trust.
You send them the next product that solves the next logical problem.
The first sale was the introduction.
The list is the business.

SECOND PRODUCT IDENTIFICATION:

  AFTER THE FIRST PRODUCT SOLVES [problem A]:
  What is the buyer's next problem?

  ASK YOUR EMAIL LIST (email 3 from the sequence above):
    "What would you want from a [related product]?"
    The answers are your second product brief.

  SIGNAL SOURCES FOR SECOND PRODUCT:
    - Email replies from your buyers
    - 3-star reviews: "I wish it also tracked [X]"
    - Reddit: "I have [product A], now I need [product B]"
    - Google: "[product A] + [related need]"

RECORD THE SECOND PRODUCT IDEA:
  First product solves  : [problem A]
  After using it, buyer now needs : [problem B]
  Second product idea   : [brief description]
  Estimated price       : $[X]
  Revenue potential if [N] buyers buy: $[X]
```

---

## Output File: room_plan.md

```markdown
# Room Plan
Pipeline step: 4 of 6
Date: [date]
Product: [from offer_spec.md]

---

## Strategy
Launch platform       : Etsy first / Own page only
Room platform         : [Gumroad / Lemon Squeezy / etc.]
Email platform        : [Kit / Beehiiv / MailerLite / etc.]

## Checkout Page Plan
Headline              : [transformation headline]
Subheadline           : [moment + credibility]
Room price            : $[X]
Guarantee             : YES / NO — [terms]
Platform URL          : [to be created]

## Email Capture Bridge
Method                : [Bonus in file / YouTube tutorial / thank-you page]
Bonus described as    : [what the bonus is called]
Opt-in page URL       : [to be created]

## Welcome Sequence
Email 1 — Day 0  : Delivery + first step
Email 2 — Day 3  : Tip + engagement
Email 3 — Day 7  : Trust + second product research

## Second Product
First product solves  : [problem A]
Next logical problem  : [problem B]
Second product idea   : [description]
Validation method     : Email 3 reply / Reddit / reviews
Revenue estimate      : $[X] at $[price] with [N] buyers

## Etsy-to-Room Bridge
Bridge method used    : [describe]
Trigger point in product: [where the link/CTA appears]
Landing page URL      : [to be created]

---

## Pipeline Status
Step 1 ✅ signal-hunter  → signal_report.md
Step 2 ✅ gap-finder     → gap_report.md
Step 3 ✅ offer-architect→ offer_spec.md
Step 4 ✅ room-builder   → room_plan.md
Step 5 ⬜ product-launcher→ launch_checklist.md
Step 6 ⬜ empire-scaler  → scale_plan.md
```

---

## Review Gate (MANDATORY)

After saving `room_plan.md`, present this EXACTLY:

```
✅ Room plan complete. Saved to room_plan.md.

📋 Summary:
- Launch strategy     : [Etsy first / own page]
- Room platform       : [platform]
- Email platform      : [platform]
- Bridge method       : [describe]
- Checkout headline   : [headline]
- Second product idea : [brief]
- Revenue multiplier  : if [N] buyers per month buy second product at $[X] → $[Y]/month

👉 You can:
  - Approve → say "approved" or "prepare to launch"
  - Change the room platform → say "use [platform] instead"
  - Adjust the bridge → say "change the bridge to [method]"
  - Refine email sequence → say "rewrite email [N]"

⏸️ Waiting for approval before Product Launcher runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `prepare to launch`, `product launcher`,
`proceed`, `next`, `go`, `room approved`, `ready to build`
