---
name: empire-scaler
description: >
  Step 6 of 6 in the Etsy Demand Arbitrage Pipeline. Takes the validated,
  launched product and scales it: second product to existing buyers, traffic
  diversification away from Etsy, pricing ladder (Etsy → own page → premium),
  and the demand arbitrage multiplier (from $14k to $140k by owning the room).
  Saves as scale_plan.md.
---

# Empire Scaler

The $20 guy is doing $14,000 a month.
He built a $97 product and he is standing somewhere that will only ever pay him 20.
You can see the same decision from here.
Same 4 seconds. Same empty box.
The difference between $14,000 and $140,000 is not a new product.
It is a room change and an email send.
This is how you do it. Save as `scale_plan.md`.

---

## Prerequisites

```
READ FIRST: signal_report.md → niche validation, top competitor data
READ SECOND: offer_spec.md   → product, transformation, room price
READ THIRD: room_plan.md     → platform, email list, second product idea
READ FOURTH: launch_checklist.md → what has shipped, what feedback exists
```

---

## The Demand Arbitrage Multiplier

```
THE VIDEO'S CORE THESIS IN ONE PARAGRAPH:

  The $20 guy has 708 buyers a month who explicitly told him:
  "I am trying to get my finances under control."
  He will never speak to them again.
  But what if he owned those 708 contacts?

  Next month, he sends one email: the debt payoff tracker, $27.
  Assume 15% of them buy → 106 sales × $27 = $2,862 in one send.
  Month after that: the savings goal planner, $37.
  15% × 708 = 106 × $37 = $3,922.
  Three products. Three months. Same 708 people.
  Added revenue: $6,784 without a new Etsy listing.

  That is demand arbitrage.
  You are not selling more people. You are selling better to the same people.
  They already told you their problem. You already earned their trust.
  The list IS the business.

THE MULTIPLIER FORMULA:
  Monthly buyers × email opt-in rate × second product conversion × price
  = monthly multiplier revenue

  Conservative estimate:
    708 buyers × 30% opt-in = 212 on your list
    212 × 15% buy second product × $27 = $858/month added from one email
    At $97 second product: 212 × 15% × $97 = $3,085/month added

  At scale (own page, no Etsy aisle):
    Room price $97 × 708 = $68,676/month
    Second product $47 × 15% × 708 = $4,982/month
    Total: $73,658/month from the same demand the $20 guy is capturing at $14,000.
    That is the 5× multiplier. Same demand. Different room.
```

---

## Step 1 — The Second Product

```
PRINCIPLE: One person with one problem.
  You solved problem A. Now solve problem B for the same person.
  The first sale was the introduction. The second sale is the business.

SECOND PRODUCT IDENTIFICATION:
  Source 1: Email 3 replies from your buyers ("what would you want next?")
  Source 2: 3-star reviews of YOUR listing (what you are still missing)
  Source 3: Reddit threads your buyers posted after buying your product
  Source 4: Google: "[your product type] + [next logical need]"

THE LOGICAL SEQUENCE (examples):

  First product     → Second product
  Budget planner    → Debt payoff tracker
  Budget planner    → Savings goal planner
  Wedding checklist → Day-of timeline template
  Resume template   → Cover letter template
  Meal planner      → Grocery list by store template
  Business finance  → Invoice + client tracker

BUILD RULE FOR SECOND PRODUCT:
  It must be bought by the same person.
  It must solve the next problem they have AFTER using the first product.
  It must be priced higher than the first product, or bundle with it.

SECOND PRODUCT PRICING:
  Option A: Same price, sold separately
  Option B: Higher price (second product is more complex)
  Option C: Bundle — both products at 60–70% of combined list price
             → Bundles increase order value and reduce decision friction

SECOND PRODUCT LAUNCH SEQUENCE:
  Week 1: Send Email 3 (research email) — "what would you want next?"
  Week 2: Build based on top responses
  Week 3: Email your list: "I built what you asked for — here it is"
  Week 4: Update your Etsy listing to mention the second product as a bundle option
```

---

## Step 2 — The Room Migration (Etsy → Own Page)

```
IF YOU ARE STILL ON ETSY ONLY:

  TIMELINE:
    Month 1: Launch on Etsy. Collect reviews, sales data, email opt-ins.
    Month 2: Set up your own checkout page. Same product, room price.
    Month 3: Redirect bridge traffic to your page. Build email list.
    Month 6: Etsy is now optional. Your page is the primary room.

  THE MIGRATION DOES NOT MEAN CLOSING ETSY.
    Etsy keeps sending you discovery traffic.
    Your page keeps the customer relationship.
    Both run. Etsy feeds the top of the funnel. Your room captures the value.

THE ROOM PRICE MIGRATION:
  You cannot suddenly change your Etsy price from $20 to $97.
  Etsy buyers expect aisle pricing.
  But you CAN:
    → Set your own page at $97 from day one
    → Keep Etsy at $20 as the entry point
    → Upsell from the product file: "Get the premium version at [your URL]"
    → The premium version has extras: more tabs, 1:1 setup call, bonus templates

  THE PRICE LADDER:
    Etsy: $20 (high volume, low margin, discovery)
    Own page basic: $47–$67 (medium volume, good margin)
    Own page premium: $97–$197 (lower volume, highest margin)
    Bundle: $[basic + premium combined × 0.65]

  You are not choosing one price. You are building a ladder.
  Let each buyer choose the step they are ready for.
```

---

## Step 3 — Traffic Diversification

```
THE ETSY DEPENDENCY WARNING:
  "That listing is one algorithm change from a very bad Tuesday."

  Etsy can:
    - Change its search algorithm (happened 2024)
    - Increase seller fees
    - Derank listings that move off-platform
    - Close your shop for a policy violation you did not know existed

  YOU NEED AT LEAST ONE OTHER TRAFFIC SOURCE before month 6.

TRAFFIC SOURCE OPTIONS (pick ONE to start, add others later):

  1. YOUTUBE TUTORIAL CHANNEL (highest leverage, slowest to build)
     What: tutorials that teach people to use your product type
     Why: search traffic is permanent. A tutorial from 2 years ago
          still sends buyers today. The $20 guy proved this.
     Content: "How to [solve problem your product solves] with Google Sheets"
     Length: 8–15 minutes, instructional, real screen share

  2. PINTEREST (fastest for digital products, free, visual)
     What: pin images of your product, your listing, your tutorial screenshots
     Why: Pinterest is a search engine. Pins resurface for years.
     Frequency: 5–10 pins per week, mix product and educational content

  3. SHORT-FORM VIDEO (TikTok / Instagram Reels / YouTube Shorts)
     What: "I made $[X] selling a spreadsheet. Here's what's in it."
     Why: build-in-public content drives curiosity traffic fast
     Risk: algorithm-dependent. Do not make this your only source.

  4. EMAIL NEWSLETTER (most reliable, entirely owned)
     What: weekly or bi-weekly email to your list
     Content: tips related to your niche + product updates + new launches
     Growth: every new buyer joins. Cross-promote at the end of each email.

  5. SEO (slowest, most durable)
     What: a simple blog or website targeting the Google autocomplete
           phrases you found in gap_report.md
     Why: the people typing those questions are buying your product
     Platform: a free GitHub Pages site or Carrd is enough to start

MINIMUM VIABLE TRAFFIC PLAN:
  Source 1 (required): Pinterest (free, visual, permanent traffic)
  Source 2 (add at month 2): YouTube tutorial OR short-form video
  Source 3 (add at month 4): Email newsletter to your growing list
```

---

## Step 4 — The 90-Day Scale Target

```
BUILD THIS PLAN NOW. REVIEW IT IN 90 DAYS.

MONTH 1 — LAUNCH:
  Target: First [N] sales
  Platform: [Etsy / own page]
  Revenue target: $[X]
  Actions: list live, tutorial recorded, email sequence active

MONTH 2 — FEEDBACK + SECOND PRODUCT:
  Target: [N] email subscribers
  Action: ship first update based on feedback
  Action: begin building second product from Email 3 research
  Revenue target: $[X] (first product only)

MONTH 3 — SECOND PRODUCT LAUNCH:
  Target: launch second product to email list
  Revenue: first product $[X] + second product launch revenue $[X]
  Action: add Pinterest as traffic source
  Action: set up own checkout page if not already live

THE ANNUAL MATH (conservative, based on video's real data):
  $20 on Etsy × 708 sales/month = $14,000/month = $168,000/year
  $97 own page × 200 sales/month = $19,400/month
  + Second product $47 × 10% of list × 200 email subs = $940/month
  Combined: $20,340/month = $244,080/year from the same demand.

  You do not need 10,000 sales a month.
  You need the right room for the demand that already exists.
```

---

## Output File: scale_plan.md

```markdown
# Scale Plan
Pipeline step: 6 of 6
Date: [date]
Product: [product name]

---

## Demand Arbitrage Multiplier
Current monthly buyers       : [N]
Email opt-in rate target      : [X]%
Email list size (month 3)     : [N]
Second product price          : $[X]
Second product conversion     : [X]%
Added monthly revenue (est.)  : $[X]

## Second Product
Name / description      : [brief]
Problem it solves       : [buyer's next problem after product 1]
Price                   : $[X]
Launch timeline         : [month / week]
Validation source       : Email replies / reviews / Reddit

## Price Ladder
Etsy                    : $[X]
Own page — basic        : $[X]
Own page — premium      : $[X]
Bundle                  : $[X]
Current active tier     : [which one is live]

## Room Migration Timeline
Month 1 : Etsy only
Month 2 : Own checkout page live at $[X]
Month 3 : Email bridge capturing [X]% of Etsy buyers
Month 6 : [X]% of revenue from own page vs Etsy

## Traffic Diversification
Source 1 (active)       : [platform + content type]
Source 2 (add month 2)  : [platform]
Source 3 (add month 4)  : [platform]

## 90-Day Revenue Target
Month 1  : $[X]
Month 2  : $[X]
Month 3  : $[X]
Assumptions: [brief]

## Annual Projection
Current trajectory (Etsy only) : $[X]/year
Room-and-list trajectory       : $[X]/year
Multiplier                     : [X]×

---

## Pipeline Status
Step 1 ✅ signal-hunter  → signal_report.md
Step 2 ✅ gap-finder     → gap_report.md
Step 3 ✅ offer-architect→ offer_spec.md
Step 4 ✅ room-builder   → room_plan.md
Step 5 ✅ product-launcher→ launch_checklist.md
Step 6 ✅ empire-scaler  → scale_plan.md

🎉 Pipeline complete. All 6 steps done.
```

---

## Review Gate (MANDATORY)

After saving `scale_plan.md`, present this EXACTLY:

```
✅ Scale plan complete. Saved to scale_plan.md.

📋 Final Pipeline Summary:
- Niche validated     : [from signal_report.md]
- Gap identified      : [from gap_report.md]
- Offer designed      : [product name, $X price]
- Room built          : [platform, email platform]
- Product launched    : [status]
- Scale plan          : [second product, 90-day target, $X/month]

Revenue trajectory:
  Etsy only      : $[X]/month
  Room + list    : $[X]/month
  With 2 products: $[X]/month

The demand was public the whole time.
You found it. You validated it. Now go build the room.

👉 You can:
  - Start over with a new niche → say "new niche: [category]"
  - Build the second product now → say "build second product"
  - Revisit any step → say "revisit [step name]"
  - Export this plan → say "export all 6 reports"

⏸️ Pipeline complete. No further automatic steps.
```

**NEVER** proceed automatically.

Approval keywords: `new niche`, `build second product`, `revisit`,
`export`, `done`, `complete`, `start over`
